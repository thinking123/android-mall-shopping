package com.lr.baseview.utils;

/**
 * 普通静态变量存储类
 * @author liushubao
 * Created by admin on 2017/3/13.
 */

public class ComConstant {

    public static final String CLOSE_ACTION = "com.yunlan.bdataplatform.CLOSE_ACTION";
}
