package com.lr.baseview.common;

/**
 * 检测登录成功的操作
 * Created by Administrator on 2017/8/3.
 */

public interface LoginSucListener {
    void onLoginSucClick();
}
